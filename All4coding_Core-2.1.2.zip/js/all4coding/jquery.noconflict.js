window.all4coding = window.all4coding || {};
all4coding.jQuery = jQuery.noConflict();