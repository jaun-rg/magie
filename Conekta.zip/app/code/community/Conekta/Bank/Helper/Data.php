<?php

class Conekta_Bank_Helper_Data extends Mage_Core_Helper_Abstract
{

}
