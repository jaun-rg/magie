<?php
class Conekta_Address extends Conekta_Resource
{
}
?>
