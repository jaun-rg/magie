<?php
class Conekta_Method extends Conekta_Resource
{
}
?>
